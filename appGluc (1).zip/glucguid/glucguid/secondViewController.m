//
//  secondViewController.m
//  glucguid
//
//  Created by Hariharan Jayaraman on 2015-06-30.
//  Copyright (c) 2015 Hariharan Jayaraman. All rights reserved.
//

#import "secondViewController.h"
#import "ViewController.h"
#import "imageViewCell.h"
@implementation secondViewController

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [_ttoken count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    imageViewCell  *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    NSString *url=[self.ttoken objectAtIndex:indexPath.row];
    NSURL *imageUrl=[NSURL URLWithString:url];
    NSData *data=[NSData dataWithContentsOfURL:imageUrl];
    
    cell.myImage.image=[UIImage imageWithData:data];
    
    return cell;
    
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(150.0, 150.0);
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    
    return UIEdgeInsetsMake(5, 5, 5, 5);
    
}

-(void)viewDidLoad
{
    [super viewDidLoad];
   
   
    
    
    NSLog(@"transToken:%@",_ttoken);
    

}
@end
