//
//  ViewController.h
//  glucguid
//
//  Created by Hariharan Jayaraman on 2015-06-30.
//  Copyright (c) 2015 Hariharan Jayaraman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "secondViewController.h"

@interface ViewController : UIViewController<UIWebViewDelegate>

@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) NSString *transToken;
@property (strong, nonatomic) IBOutlet UITextField *userNameText;
@property (strong, nonatomic) NSMutableArray *ImageURL;
- (IBAction)goButton:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *hideLbl;


@end

