//
//  secondViewController.h
//  glucguid
//
//  Created by Hariharan Jayaraman on 2015-06-30.
//  Copyright (c) 2015 Hariharan Jayaraman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (strong,nonatomic) NSMutableArray *ttoken;

@property(nonatomic,weak) IBOutlet UICollectionView *myCollectionView;

@end
