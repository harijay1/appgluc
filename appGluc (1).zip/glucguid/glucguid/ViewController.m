//
//  ViewController.m
//  glucguid
//
//  Created by Hariharan Jayaraman on 2015-06-30.
//  Copyright (c) 2015 Hariharan Jayaraman. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *itkeys;
    NSDictionary *values;
    NSDictionary *picFinal;
    NSDictionary *imageDic;
    int count;
    
    
}
@end

@implementation ViewController
-(void)passValue:(NSMutableArray*)newArray
{
    secondViewController *obj1=[[secondViewController alloc]init];
    obj1.ttoken=newArray;
    NSLog(@"Inside pass value %@",obj1.ttoken);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    count=0;
    _ImageURL=[[NSMutableArray alloc]init];
   
    NSString *logOut=[[NSString alloc]init];
    logOut=[NSString stringWithFormat:@"https://instagram.com/accounts/logout"];
    NSURL *logOutUrl=[NSURL URLWithString:logOut];
    NSURLRequest *logOutRequest=[NSURLRequest requestWithURL:logOutUrl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    NSData *logOutData=[NSURLConnection sendSynchronousRequest:logOutRequest returningResponse:nil error:nil];
    
    [self.webView loadRequest:logOutRequest];
    
    
    


NSString *urlString=[[NSString alloc]init];
    urlString=[NSString stringWithFormat:@"https://instagram.com/oauth/authorize/?client_id=6a46ba6144e745cfb7a67b702dad1dff&redirect_uri=http://educationhari.wix.com/1-pager-bio-r&response_type=token"];
    
    self.transToken=[[NSString alloc]init];
    
    NSURL *url=[NSURL URLWithString:urlString];
    
    
    NSURLRequest *theRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    NSData *dataq=[NSURLConnection sendSynchronousRequest:theRequest returningResponse:nil error:nil];
    [self.webView loadRequest:theRequest];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
   
}

-(void)dismissKeyboard {
    [self.userNameText resignFirstResponder];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    
    NSLog(@"Did start load");
}
 - (void)webViewDidFinishLoad:(UIWebView *)webView
{
    
    count=count+1;
    NSLog(@"Count->%i",count);
    if(count==2)
    {
        self.webView.hidden=YES;
    }
    NSLog(@"Finished Loading");
}

    
 -(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    if ([[segue identifier]isEqualToString:@"descsegue"]) {
        
        secondViewController *dc=[segue destinationViewController];
        [dc setTtoken:_ImageURL];
        
    }
    
}
    
    

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)goButton:(id)sender {
    
    self.transToken = [self.webView.request.URL fragment];
    NSLog(@"Fragment:%@",self.transToken);
    
  
    NSDate *date=[NSDate date];
    NSDate *twoDaysAgo=[date dateByAddingTimeInterval:-2*24*60*60];
    NSTimeInterval ti=[twoDaysAgo timeIntervalSince1970];
    NSLog(@"UNIX DATE : %f",ti);
        
    NSString *searchString=[[NSString alloc]init];
    searchString=[NSString stringWithFormat:@"https://api.instagram.com/v1/users/self/media/recent/?%@&max_timestamp=%f",_transToken,ti];
    
   
    
    NSURL *url=[NSURL URLWithString:searchString];
    
    
    NSURLRequest *theRequest=[NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
    
    NSData *dataq=[NSData dataWithContentsOfURL:url];
    
    NSError *error;
    NSDictionary* json=[NSJSONSerialization JSONObjectWithData:dataq options:kNilOptions error:&error];
    
    NSArray* pictures=[json objectForKey:@"data"];
    
    NSSet* test=[NSSet setWithArray:pictures];
   
    for (id item in test) {
        NSArray *itemKeys=[[NSArray alloc]init];
        itemKeys=[item allKeys];
        
        itkeys=[[NSArray alloc]initWithArray:itemKeys];
        values=[item objectForKey:@"images"];
        NSArray *secKey=[[NSArray alloc]init];
        secKey=[values allKeys];
        
        picFinal=[values objectForKey:@"standard_resolution"];
        
        
        NSString *buffer=[[NSString alloc]init];
        buffer=[picFinal objectForKey:@"url"];
        [_ImageURL addObject:buffer];
        
        NSLog(@"item------>%@",buffer);
        
        
    }
    
    [self passValue:_ImageURL];
    
    
   
    }

@end
