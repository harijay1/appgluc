//
//  imageViewCell.h
//  glucguid
//
//  Created by Hariharan Jayaraman on 2015-06-30.
//  Copyright (c) 2015 Hariharan Jayaraman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageViewCell : UICollectionViewCell
@property (nonatomic,weak)IBOutlet UIImageView *myImage;
@end
